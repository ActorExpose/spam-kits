<!--

www.X E O N sMs SENDER © 2020

contact us : bulksms.us@gmail.com

-->
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <link href="https://i.imgur.com/hh4v20F.png" rel="icon" type="image/x-icon"/>
  <title>Bulk SMS Sender | X E O N sMs SENDER</title>
  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.1/css/bootstrap.css'>
<link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.0.13/css/all.css'><link rel="stylesheet" href="assets/style2.css">

</head>
<body>
<!-- partial:index.partial.html -->
<div class="page-wrapper chiller-theme toggled">
  <a id="show-sidebar" class="btn btn-sm btn-dark" href="#">
    <i class="fas fa-bars"></i>
  </a>
  <nav id="sidebar" class="sidebar-wrapper">
    <div class="sidebar-content">
      <div class="sidebar-brand">
        <a href="#">admin panel</a>
        <div id="close-sidebar">
          <i class="fas fa-times"></i>
        </div>
      </div>
      <div class="sidebar-header">
        <div class="user-pic">
          <img class="img-responsive img-rounded" src="https://i.imgur.com/Vpx6L4r.jpg"
            alt="User picture">
        </div>
        <div class="user-info">
          <span class="user-name">Jhon
            <strong>Smith</strong>
          </span>
          <span class="user-role">Administrator</span>
          <span class="user-status">
            <i class="fa fa-circle"></i>
            <span>Online</span>
          </span>
        </div>
      </div>
    
      <div class="sidebar-menu">
        <ul>
          
          <li class="s">
            <a href="#">
              <i class=""></i>
            <strong><font size="2px" color="#EEEA17">&#9675;	</font><font color="#09E5B3">Dashboard</font></strong>
            </a>
			
<style>
hr.new2 {border-top: 1px dashed #5cb85c; width:100%;}
</style>
<hr class='new2'>
            <div class="sidebar-submenu">
             
            </div>
          </li>
          
          
          <li class="s">
            <a href="tools/generator">
              <i class=""></i>
               <strong>&#149;	 <font color="#09E5B3" face="Candara" >Phone Number Generator</font> </strong>
            </a>
<style>
hr.new2 {border-top: 1px dashed #5cb85c; width:100%;}
</style>
<hr class='new2'>
            <div class="sidebar-submenu">
              
            </div>
          </li>

          <li>
            <a href="tools/info-valid/">
              <i class=""></i>
             <strong>&#149;  <font color="#09E5B3"face="Candara">Phone Number INFO</font></strong>
            </a>
<style>
hr.new2 {border-top: 1px dashed #5cb85c; width:100%;}
</style>
<hr class='new2'>
          </li>
		  
		  
		    <li>
            <a href="tools/extractor" target="_blank">
              <i class=""></i>
             <strong>&#149;  <font color="#09E5B3" face="Candara">Phone Number Extractor</font></strong>     
            </a>
<style>
hr.new2 {border-top: 1px dashed #5cb85c; width:100%;}
</style>
<hr class='new2'>
          </li>
		  
		  <li>
            <a href="tools/addplus">
              <i class=""></i>
            <strong>&#149;  <font color="#09E5B3" face="Candara">Add Plus</font></strong>
            </a>
<style>
hr.new2 {border-top: 1px dashed #5cb85c; width:100%;}
</style>
<hr class='new2'>
          </li>
		  
		  
		    <li>
            <a href="tools/api">
              <i class=""></i>
            <strong>&#149;  <font color="#09E5B3" face="Candara">Nexmo Api Balance</font></strong>
            </a>

          </li>
		  
		    
      
	    
        </ul>
      </div>
      <!-- sidebar-menu  -->
    </div>
    <!-- sidebar-content  -->
    <div class="sidebar-footer">
     
      <a href="http://X E O N sMs SENDER" target="_blank" title="www.X E O N sMs SENDER" >
        <b><font color="#E3E910" face="verdana">www.X E O N sMs SENDER</font></b> <font color="#E3E910" face="verdana"> &#169;	</font>
      </a>
    </div>
  </nav>
  <!-- sidebar-wrapper  -->
  <main class="page-content">
    <div class="container-fluid">
  
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Bulk SMS Sender | X E O N sMs SENDER</title>
        <link href="assets/style.css" rel="stylesheet" type="text/css"/>
        <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    </head>
    <body>
<div style="padding-top:10px;">	
<center>
<b><font size="7px" color="#1919DF" face="verdana" >www.X E O N sMs SENDER</font>   
</center>
</div>
        <div class="container">
         <center>   <div style="padding-left:30px;"><b><font size="7px" color="#6A0F8E" face="Arial Black"> Bulk SMS Sender</font></b></div>
			<br/>
			</center>
            <div id="responce" style="padding-left:5px; color:#186A3B; face:verdana;"></div>
<br/>
            <div class="cntr">
                
                 <label for="rdo-0" class="btn-radio">
                    <input type="radio" id="rdo-0" name="radio-grp" value="nexmo">
                    <svg width="20px" height="20px" viewBox="0 0 20 20">
                    <circle cx="10" cy="10" r="9"></circle>
                    <path d="M10,7 C8.34314575,7 7,8.34314575 7,10 C7,11.6568542 8.34314575,13 10,13 C11.6568542,13 13,11.6568542 13,10 C13,8.34314575 11.6568542,7 10,7 Z" class="inner"></path>
                    <path d="M10,1 L10,1 L10,1 C14.9705627,1 19,5.02943725 19,10 L19,10 L19,10 C19,14.9705627 14.9705627,19 10,19 L10,19 L10,19 C5.02943725,19 1,14.9705627 1,10 L1,10 L1,10 C1,5.02943725 5.02943725,1 10,1 L10,1 Z" class="outer"></path>
                    </svg>
                    <span>Nexmo</span>
                </label>
                
                <label for="rdo-1" class="btn-radio">
                    <input type="radio" id="rdo-1" name="radio-grp" value="twilio">
                    <svg width="20px" height="20px" viewBox="0 0 20 20">
                    <circle cx="10" cy="10" r="9"></circle>
                    <path d="M10,7 C8.34314575,7 7,8.34314575 7,10 C7,11.6568542 8.34314575,13 10,13 C11.6568542,13 13,11.6568542 13,10 C13,8.34314575 11.6568542,7 10,7 Z" class="inner"></path>
                    <path d="M10,1 L10,1 L10,1 C14.9705627,1 19,5.02943725 19,10 L19,10 L19,10 C19,14.9705627 14.9705627,19 10,19 L10,19 L10,19 C5.02943725,19 1,14.9705627 1,10 L1,10 L1,10 C1,5.02943725 5.02943725,1 10,1 L10,1 Z" class="outer"></path>
                    </svg>
                    <span>Twilio</span>
                </label>
                <label for="rdo-2" class="btn-radio">
                    <input type="radio" id="rdo-2" name="radio-grp" value="textlocal">
                    <svg width="20px" height="20px" viewBox="0 0 20 20">
                    <circle cx="10" cy="10" r="9"></circle>
                    <path d="M10,7 C8.34314575,7 7,8.34314575 7,10 C7,11.6568542 8.34314575,13 10,13 C11.6568542,13 13,11.6568542 13,10 C13,8.34314575 11.6568542,7 10,7 Z" class="inner"></path>
                    <path d="M10,1 L10,1 L10,1 C14.9705627,1 19,5.02943725 19,10 L19,10 L19,10 C19,14.9705627 14.9705627,19 10,19 L10,19 L10,19 C5.02943725,19 1,14.9705627 1,10 L1,10 L1,10 C1,5.02943725 5.02943725,1 10,1 L10,1 Z" class="outer"></path>
                    </svg>
                    <span>Textlocal</span>
                </label>
                <div style="clear: both;"></div>
            </div>
            <form action="" method="post" onclick="return false">
			<div style="padding-left:9px;" >
			<input type="text"  name="sender" placeholder="Sender ID : info / Google / Apple / Facebook ..." id="sender" 
			style ="margin-top:15px;padding-left:15px;width:620px;height: 25px; border: 1px solid #ccc; "/><br >
			</div>
			<div style="clear: both;" ></div>
                <div class="float-left comman">		
                    <textarea placeholder="Message" id="message"></textarea>
                </div>
                <div class="float-rigth comman">
                    <textarea placeholder="Phone Number List" id="numbers"></textarea>
                </div>
                <div style="clear: both">
                    <input type="submit" id="submit-btn" onmousedown="start_sendig();" value="Send SMS now!">
                </div>
            </form>
			
        </div>
<center>
<a href="http://X E O N sMs SENDER" target="_blank"><b><font color="#1919DF" face="verdana" size="2px" >www.X E O N sMs SENDER  &#169; 2020</b></a>
</center>
</br></br>
<script src="https://code.jquery.com/jquery-2.2.4.min.js" type="text/javascript"></script>
<script src="assets/main.js" type="text/javascript"></script>
</body>
</html>
  
</main>
</div>
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/esm/popper.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.1/js/bootstrap.js'></script><script  src="assets/script2.js"></script>

</body>
</html>
<!--

www.X E O N sMs SENDER © 2020

contact us : bulksms.us@gmail.com

-->