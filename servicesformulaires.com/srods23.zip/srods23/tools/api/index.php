<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <link href="https://i.imgur.com/hh4v20F.png" rel="icon" type="image/x-icon"/>
  <title>Nexmo Api balance</title>
  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.1/css/bootstrap.css'>
<link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.0.13/css/all.css'><link rel="stylesheet" href="assets/style2.css">

</head>
<body>
<div class="page-wrapper chiller-theme toggled">
  <a id="show-sidebar" class="btn btn-sm btn-dark" href="#">
    <i class="fas fa-bars"></i>
  </a>
  <nav id="sidebar" class="sidebar-wrapper">
    <div class="sidebar-content">
      <div class="sidebar-brand">
        <a href="#">Admin panel</a>
        <div id="close-sidebar">
          <i class="fas fa-times"></i>
        </div>
      </div>
      <div class="sidebar-header">
        <div class="user-pic">
          <img class="img-responsive img-rounded" src="https://i.imgur.com/Vpx6L4r.jpg"
            alt="User picture">
        </div>
        <div class="user-info">
          <span class="user-name">Jhon
            <strong>Smith</strong>
          </span>
          <span class="user-role">Administrator</span>
          <span class="user-status">
            <i class="fa fa-circle"></i>
            <span>Online</span>
          </span>
        </div>
      </div>
    
      <div class="sidebar-menu">
        <ul>
          
          <li class="s">
            <a href="../././../index.php">
              <i class=""></i>
			  
               <strong>&#149;  <font color="#09E5B3"face="Candara">Dashboard </font></strong>
              
            </a>
<style>
hr.new2 {border-top: 1px dashed #5cb85c; width:100%;}
</style>
<hr class='new2'>
            <div class="sidebar-submenu">
             
            </div>
          </li>
          
          
          <li class="s">
            <a href=".././generator">
              <i class=""></i>
               <strong>&#149;	 <font color="#09E5B3" face="Candara" >Phone Number Generator</font> </strong>

            </a>
<style>
hr.new2 {border-top: 1px dashed #5cb85c; width:100%;}
</style>
<hr class='new2'>
            <div class="sidebar-submenu">
              
            </div>
          </li>

          <li>
            <a href=".././info-valid">
              <i class=""></i>
             <strong>&#149;  <font color="#09E5B3"face="Candara">Phone Number INFO</font></strong>
            </a>
<style>
hr.new2 {border-top: 1px dashed #5cb85c; width:100%;}
</style>
<hr class='new2'>
          </li>
		  
		  
		    <li>
             <a href=".././extractor" target="_blank">
              <i class=""></i>
             <strong>&#149;  <font color="#09E5B3" face="Candara">Phone Number Extractor</font></strong>     
            </a>
<style>
hr.new2 {border-top: 1px dashed #5cb85c; width:100%;}
</style>
<hr class='new2'>
          </li>
		  
		  <li>
            <a href=".././addplus">
              <i class=""></i>
             <strong>&#149;  <font color="#09E5B3"face="Candara">Add +</font></strong>
            </a>
<style>
hr.new2 {border-top: 1px dashed #5cb85c; width:100%;}
</style>
<hr class='new2'>
          </li>
		  
		    <li>
            <a href="#">
              <i class=""></i>
                           <strong><font size="4px" color="#EEEA17">&#9675;	</font><font color="#09E5B3">Nexmo Api Balance</font></strong>

            </a>
          </li>
		  
        </ul>
      </div>
      <!-- sidebar-menu  -->
    </div>
    <!-- sidebar-content  -->
    <div class="sidebar-footer">
     
      <a href="http://t.me/xe0on" target="_blank" title="X E O N" >
        <b><font color="#E3E910" face="verdana">X E O N</font></b> <font color="#E3E910" face="verdana"> &#169;	</font>
      </a>
    </div>
  </nav>
  <!-- sidebar-wrapper  -->
  <main class="page-content">
    <div class="container-fluid">
  
<?php
error_reporting(0);
function Jib_Info($ramz, $index){
	if (preg_match_all($ramz, $index, $natija)) { 
	foreach ($natija[1] as $info) {
	if (count($info) > 0) return ' '.$info;
	}
	}else{
	return '';
	}
	}	
$file = "../././../nexmo-api.txt";
$get = file($file);
$ch = curl_init();
$api_key = $_SESSION['api_key'] = $get[0];
$api_secret = $_SESSION['api_secret'] = $get[1];
$url = "https://rest.nexmo.com/account/get-balance/$api_key/$api_secret";
$url = preg_replace('/\s+/', '', $url);
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
$headers = array();
$headers[] = "Accept: application/json";
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$v = curl_exec($ch);
curl_close ($ch);
$balance = Jib_Info('/value":(.*?),/', $v);
$able = $balance / "0.0626";
?>
<!DOCTYPE html>
<html>
<head>
  <title>Nexmo Api Checker</title>
  <meta name="viewport" content="width=940, initial-scale=1.0, maximum-scale=1.0">
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
  <script src="http://code.jquery.com/jquery-2.1.3.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
</head>
<body>
<style>
  body{
  background-color: #ccc;}
  </style>
<style type="text/css">
.form-style-6{
    font: 95% Arial, Helvetica, sans-serif;
    max-width: 400px;
    margin: 10px auto;
    padding: 16px;
    background: #FFA07A;
}
.form-style-6 h1{
    background: #FFA07A;
    padding: 20px 0;
    font-size: 140%;
    font-weight: 300;
    text-align: center;
    color: #454545;
    margin: -16px -16px 16px -16px;
}
.form-style-6 input[type="text"],
.form-style-6 input[type="date"],
.form-style-6 input[type="datetime"],
.form-style-6 input[type="email"],
.form-style-6 input[type="number"],
.form-style-6 input[type="search"],
.form-style-6 input[type="time"],
.form-style-6 input[type="url"],
.form-style-6 textarea,
.form-style-6 select 
{
    -webkit-transition: all 0.30s ease-in-out;
    -moz-transition: all 0.30s ease-in-out;
    -ms-transition: all 0.30s ease-in-out;
    -o-transition: all 0.30s ease-in-out;
    outline: none;
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    width: 100%;
    background: #fff;
    margin-bottom: 4%;
    border: 1px solid #ccc;
    padding: 3%;
    color: #555;
    font: 95% Arial, Helvetica, sans-serif;
}
.form-style-6 input[type="text"]:focus,
.form-style-6 input[type="date"]:focus,
.form-style-6 input[type="datetime"]:focus,
.form-style-6 input[type="email"]:focus,
.form-style-6 input[type="number"]:focus,
.form-style-6 input[type="search"]:focus,
.form-style-6 input[type="time"]:focus,
.form-style-6 input[type="url"]:focus,
.form-style-6 textarea:focus,
.form-style-6 select:focus
{
    box-shadow: 0 0 5px #43D1AF;
    padding: 3%;
    border: 1px solid #43D1AF;
}

.form-style-6 input[type="submit"],
.form-style-6 input[type="button"]{
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    width: 100%;
    padding: 3%;
    background: #43D1AF;
    border-bottom: 2px solid #30C29E;
    border-top-style: none;
    border-right-style: none;
    border-left-style: none;    
    color: #fff;
	
}
.form-style-6 input[type="submit"]:hover,
.form-style-6 input[type="button"]:hover{
    background: #2EBC99;
	face:verdana;
}
</style>
<br/>
<center>
<b><font size="7px" color="#1919DF" face="verdana" >X E O N</font></b>   
</center>
<br/>
<div class="form-style-6">
<center>
<b><font face="verdana" color="#6A0F8E" size="4px">Nexmo Api Checker</font></b>
</center>
<form method="post" enctype="multipart/form-data" action="">
<hr>
<div calss="zoom">

<b><font face="verdana" color="#080ED3">Api Key: </font><font color="#F30602"></font> HIDDEN <font color="#F30602"></font></b>
<br/><br/>
<b><font face="verdana" color="#080ED3">Api Secret: </font><font color="#F30602"></font> HIDDEN <font color="#F30602"></font></b>
<br/><br/>
<b><font color="#080ED3" face="verdana">API BALANCE:</font> <font color="#F30602">"</font> <font face="verdana">$400</font> <font color="#F30602">"</font></b>
<br/><br/>
<b><font color="#080ED3" face="verdana">SMS ABLE TO SENT:</font> <font color="#F30602">"</font> <font face="verdana">9752</font> <font color="#F30602">"</font></b>
</div>
</center>
</div>
</form>
</div>
<br/>
<center>
<a href="http://t.me/xe0on" target="_blank"><b><font color="#1919DF" face="verdana" size="2px" >X E O N  &#169; 2020</b></a>
</center>
</body>
</html>
</main>
</div>
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/esm/popper.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.1/js/bootstrap.js'></script><script  src="assets/script2.js"></script>

</body>
</html>