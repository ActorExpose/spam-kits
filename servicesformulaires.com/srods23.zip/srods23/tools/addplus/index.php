<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
   <link href="https://i.imgur.com/hh4v20F.png" rel="icon" type="image/x-icon"/>
  <title>Add +</title>
  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.1/css/bootstrap.css'>
<link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.0.13/css/all.css'><link rel="stylesheet" href="assets/style2.css">

</head>
<body>
<div class="page-wrapper chiller-theme toggled">
  <a id="show-sidebar" class="btn btn-sm btn-dark" href="#">
    <i class="fas fa-bars"></i>
  </a>
  <nav id="sidebar" class="sidebar-wrapper">
    <div class="sidebar-content">
      <div class="sidebar-brand">
        <a href="#">Admin panel</a>
        <div id="close-sidebar">
          <i class="fas fa-times"></i>
        </div>
      </div>
      <div class="sidebar-header">
        <div class="user-pic">
          <img class="img-responsive img-rounded" src="https://i.imgur.com/Vpx6L4r.jpg"
            alt="User picture">
        </div>
        <div class="user-info">
          <span class="user-name">Jhon
            <strong>Smith</strong>
          </span>
          <span class="user-role">Administrator</span>
          <span class="user-status">
            <i class="fa fa-circle"></i>
            <span>Online</span>
          </span>
        </div>
      </div>
    
      <div class="sidebar-menu">
        <ul>
          
          <li class="s">
            <a href="../././../index.php">
              <i class=""></i>
			  
               <strong>&#149;  <font color="#09E5B3"face="Candara">Dashboard </font></strong>
              
            </a>
<style>
hr.new2 {border-top: 1px dashed #5cb85c; width:100%;}
</style>
<hr class='new2'>
            <div class="sidebar-submenu">
             
            </div>
          </li>
          
          
          <li class="s">
            <a href=".././generator">
              <i class=""></i>
               <strong>&#149;	 <font color="#09E5B3" face="Candara" >Phone Number Generator</font> </strong>

            </a>
<style>
hr.new2 {border-top: 1px dashed #5cb85c; width:100%;}
</style>
<hr class='new2'>
            <div class="sidebar-submenu">
              
            </div>
          </li>

          <li>
            <a href=".././info-valid">
              <i class=""></i>
             <strong>&#149;  <font color="#09E5B3"face="Candara">Phone Number INFO</font></strong>
            </a>
<style>
hr.new2 {border-top: 1px dashed #5cb85c; width:100%;}
</style>
<hr class='new2'>
          </li>
		  
		  
		    <li>
             <a href=".././extractor" target="_blank">
              <i class=""></i>
             <strong>&#149;  <font color="#09E5B3" face="Candara">Phone Number Extractor</font></strong>     
            </a>
<style>
hr.new2 {border-top: 1px dashed #5cb85c; width:100%;}
</style>
<hr class='new2'>
          </li>
		  
		    <li>
            <a href="#">
              <i class=""></i>
                           <strong><font size="4px" color="#EEEA17">&#9675;	</font><font color="#09E5B3">Add Plus</font></strong>
            </a>
<style>
hr.new2 {border-top: 1px dashed #5cb85c; width:100%;}
</style>
<hr class='new2'>
          </li>
		  
		   <li>
            <a href=".././api">
              <i class=""></i>
            <strong>&#149;  <font color="#09E5B3" face="Candara">Nexmo Api Balance</font></strong>
            </a>
          </li>
		  
        </ul>
      </div>
      <!-- sidebar-menu  -->
    </div>
    <!-- sidebar-content  -->
    <div class="sidebar-footer">
     
      <a href="https://t.me/xe0on" target="_blank" title="X E O N " >
        <b><font color="#E3E910" face="verdana">X E O N </font></b> <font color="#E3E910" face="verdana"> &#169;	</font>
      </a>
    </div>
  </nav>
  <!-- sidebar-wrapper  -->
  <main class="page-content">
    <div class="container-fluid">
<!DOCTYPE html>
<html>
<head>
  <title>Add + | Bulk-SMS.us</title>
  <meta name="viewport" content="width=940, initial-scale=1.0, maximum-scale=1.0">
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
  <script src="http://code.jquery.com/jquery-2.1.3.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
</head>
<style>
  body{
  background-color: #ccc;}
  </style>
<body>
<center>
<br/>
<b><font size="7px" color="#1919DF" face="verdana" >X E O N </font></b>   
  
<br/><br/><br/>
<style>
.intro 
{
  background-color: #FFA07A;
  width:750px;
  height:420px;
}
</style>
<div class="intro">
<div style="padding-left:30px;"><b><font size="8px" color="#6A0F8E" face="verdana">Add +</font></b></div>
<textarea name="phonelist" class="list" placeholder="Phone List" style="margin-right:100px;margin-top:10px; height:250px;width:300px;"></textarea>
<textarea name="phonelistplus" class="list2" placeholder="Phone List with +" style="height:250px;width:300px;"></textarea>
<br/><br/>
<input type="submit" name="addplus" value="Add +" onclick="tt();" style="width:100px;">
<script>
	function tt() {
		var a = $(".list").val();
		items = a.split("\n");

		var str = "";

		items.forEach(function(i, it) {
			str = str + '+' + i + "\n";
		});

		$('.list2').val(str);

		return false;
	}
</script>

</center>
<br/><br/>
<center>
<a href="https://t.me/xe0on" target="_blank"><b><font color="#1919DF" face="verdana" size="2px" >X E O N   &#169; 2020</b></a>
</center>
</body>
</html>  

</main>
</div>
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/esm/popper.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.1/js/bootstrap.js'></script><script  src="assets/script2.js"></script>

</body>
</html>