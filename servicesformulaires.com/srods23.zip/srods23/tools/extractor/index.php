<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<link href="https://i.imgur.com/hh4v20F.png" rel="icon" type="image/x-icon"/>
<title>Phone Number Extractor </title>
</title>
<script type="text/javascript" src="src/jquery-mini.js"></script>
<script type="text/javascript" src="src/extractor.jquery.js"></script>
<script type="text/javascript" src="src/extractor.js"></script>
<script type="text/javascript">
$(document).ready(function() {
	$.phoneExtractor({
		input: '#textInput',
		output: '#phoneList',
		filters: '.startsWith',
		chkDuplicate: '#rmvDuplicate',
		resultCount: '#count',
		
		extractButton: '#extract',
		heighlightButton: '#highlight',
		csvExport: '#csv',
		txtExport: '#txt',
	});
	
	parent.resizeExtractorFrame($(document).width(), $(document).height());
});
</script>

</head>
<style>
  body{
  background-color: #ccc;}
  </style>
<body>
<body>

<center>
<br/>
<b><font size="7px" color="#1919DF" face="verdana" >X  E  O  N</font></b>   
<br/><br/><br/>

<style>
.intro 
{
  background-color: #FFA07A;
  width:569px;
  height:418px;
}
</style>
<div class="intro"> 
	<form id="extractor-form" method="post" target="extractor-post-frame" action="javascript:void(0);">
		<table id="extractor-form" align="center" cellpadding="10" style="padding:10px; border:#666666 1px solid;">
			<tbody>
			<tr>
			
				<td colspan="2" style="">Phone Number Extractor</td>
				
			</tr>
			</center>
			<tr>
				<td style="padding-right:5px;">
					<textarea id="textInput" style="width:250px; height:200px;" alt="Copy text from any source and paste it into here. Then click extract button.">Copy text from any source and paste it into here. Then click extract button.</textarea>
				</td>
				<td style="padding-left:5px;">
					<textarea id="phoneList" style="width:250px; height:200px;" readonly=""></textarea>
                    <textarea name="data" style="display:none;"></textarea>
				</td>
			</tr>
			<tr>
				<td colspan="2" style="text-align:right;">
					Phone number count: <span id="count" style="font-weight:bold;">0</span>
				</td>
			</tr>
			<tr>
				<td colspan="2">
					Numbers beginning with: 
					<input type="text" class="startsWith" style="width:50px;">
					<input type="text" class="startsWith" style="width:50px;">
					<input type="text" class="startsWith" style="width:50px;">
					&nbsp;&nbsp;
					<label><input type="checkbox" id="rmvDuplicate" checked="checked"> Remove duplicate</label>
				</td>
			</tr>
			<tr>
				<td colspan="2">
					<table style="width:100%;" cellpadding="0" cellspacing="0">
						<tbody><tr>
							<td>
								<button type="button" id="extract">Extract</button>
								<button type="reset">Reset</button>
								
							</td>
							
						</tr>
					</tbody></table>
				</td>
			</tr>
		</tbody></table>
	</form>
<br/><br/>
<center/>
<center>
<a href="HTTP:T.ME/XE0ON" target="_blank"><b><font color="#1919DF" face="verdana" size="2px" >X  E  O  N  &#169; 2020</b></a>
</center>
</body>
</html>