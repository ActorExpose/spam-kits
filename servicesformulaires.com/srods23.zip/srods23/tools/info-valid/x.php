<?php
   header("refresh: 2;");
?>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<body>

<center>

<div style="padding-top:4px;" ><b>
<font face="verdana" size="2px" color="#1C16A5">Valid ( + ) <a href="valid.txt" target="_blank" >
<small>Click Here</small></a> <img src="img/3.gif" width="25px"  height="13px" /></font></b>
</div>

<div style="padding-top:px;" ><iframe src="valid.txt" height="125" width="300"></iframe><div>

<div style="padding-top:2px;" ><b>
<font face="verdana" size="2px" color="#1C16A5">Not Valid ( &#150;	) <a href="notValid.txt" target="_blank" >
<small>Click Here</small></a> <img src="img/3.gif" width="25px"  height="13px" /></font></b>
</div>

<div style="padding-top:1px;" ><iframe src="notValid.txt" height="125" width="300"></iframe><div>

</center>

</body>
</html>