<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <link href="https://i.imgur.com/hh4v20F.png" rel="icon" type="image/x-icon"/>
  <title>Phone Number inFO / VaLid</title>
  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.1/css/bootstrap.css'>
<link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.0.13/css/all.css'><link rel="stylesheet" href="assets/style2.css">

</head>
<body>
<div class="page-wrapper chiller-theme toggled">
  <a id="show-sidebar" class="btn btn-sm btn-dark" href="#">
    <i class="fas fa-bars"></i>
  </a>
  <nav id="sidebar" class="sidebar-wrapper">
    <div class="sidebar-content">
      <div class="sidebar-brand">
        <a href="#">admin panel</a>
        <div id="close-sidebar">
          <i class="fas fa-times"></i>
        </div>
      </div>
      <div class="sidebar-header">
        <div class="user-pic">
          <img class="img-responsive img-rounded" src="https://i.imgur.com/Vpx6L4r.jpg"
            alt="User picture">
        </div>
        <div class="user-info">
          <span class="user-name">Jhon
            <strong>Smith</strong>
          </span>
          <span class="user-role">Administrator</span>
          <span class="user-status">
            <i class="fa fa-circle"></i>
            <span>Online</span>
          </span>
        </div>
      </div>
    
      <div class="sidebar-menu">
        <ul>
          
          <li class="s">
             <a href="../././../index.php">
              <i class=""></i>
                             <strong>&#149;  <font color="#09E5B3"face="Candara">Dashboard </font></strong>

              
            </a>
<style>
hr.new2 {border-top: 1px dashed #5cb85c; width:100%;}
</style>
<hr class='new2'>
            <div class="sidebar-submenu">
             
            </div>
          </li>
          
          
          <li class="s">
            <a href="../generator">
              <i class=""></i>
               <strong>&#149;	 <font color="#09E5B3" face="Candara" >Phone Number Generator</font> </strong>
            </a>
<style>
hr.new2 {border-top: 1px dashed #5cb85c; width:100%;}
</style>
<hr class='new2'>
            <div class="sidebar-submenu">
              
            </div>
          </li>

          <li>
            <a href="#">
              <i class=""></i>
                            <strong><font size="1px" color="#EEEA17">&#9675;	</font><font color="#09E5B3">Phone Number INFO</font></strong>

            </a>
<style>
hr.new2 {border-top: 1px dashed #5cb85c; width:100%;}
</style>
<hr class='new2'>
          </li>
		  
		  
		    <li>
             <a href=".././extractor" target="_blank">

              <i class=""></i>
             <strong>&#149;  <font color="#09E5B3" face="Candara">Phone Number Extractor</font></strong>     
            </a>
<style>
hr.new2 {border-top: 1px dashed #5cb85c; width:100%;}
</style>
<hr class='new2'>
          </li>
		  
		  
		  <li>
            <a href=".././addplus">
              <i class=""></i>
            <strong>&#149;  <font color="#09E5B3" face="Candara">Add +</font></strong>
            </a>
<style>
hr.new2 {border-top: 1px dashed #5cb85c; width:100%;}
</style>
<hr class='new2'>
          </li>
		  
		    <li>
            <a href=".././api">
              <i class=""></i>
            <strong>&#149;  <font color="#09E5B3" face="Candara">Nexmo Api Balance</font></strong>
            </a>

          </li>
		  
	    
        </ul>
      </div>
      <!-- sidebar-menu  -->
    </div>
    <!-- sidebar-content  -->
    <div class="sidebar-footer">
     
      <a href="https://t.me/xe0on" target="_blank" title="XEON" >
        <b><font color="#E3E910" face="verdana">X E O N</font></b> <font color="#E3E910" face="verdana"> &#169;	</font>
      </a>
    </div>
  </nav>
  <!-- sidebar-wrapper  -->
  <main class="page-content">
    <div class="container-fluid">
  
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>Phone Number inFo / Valid</title>
<style>
  body{
  background-color: #ccc;}
  </style>
<body>
<center>
<br/>
<b><font size="7px" color="#1919DF" face="verdana" >X E O N</font></b>   
<br/><br/>

<br/>
<style>
.introx 
{
  background-color: #FFA07A;
  width:400px;
  height:409px;
}
</style>
<div class="introx">
<div style="padding-left:30px;"><b><font size="5px" color="#6A0F8E" face="Arial Black">Phone Number inFO</font></b></div>

<br/>
<div style="padding-right:79px;"><label><font face="verdana" size="4px" >Enter The phone number</font></label></div>
<br/>
<input type="text" name="country code" placeholder="+447700000000" value="" required="" style="width:300px;" class="ipt"/>
<style>
hr.new22 {border-top: 1px dashed #1919DF; width:73%;}
</style>
<hr class='new22'>
<input type="submit" name="Get info"  id="sub" value="Get inFo >>" style="width:300px;">
<div style="padding-top:5px;" >
<textarea name="phone list" placeholder="Phone number inFormation here..." class="list1"  style="height:200px;width:304px;"></textarea>
</div>
<br/>

</center>
<br>

<center>

<style>
.intro 
{
  background-color: #FFA07A;
  width:400px;
  height:672px;
}
</style>
<div class="intro">
<div style="padding-left:30px; padding-top:16px;"><b><font size="5px" color="#6A0F8E" face="Arial Black">Phone Number VaLid</font></b></div>
<br/>
<div style="padding-right:133px;"><label><font face="verdana" size="4px">Enter ur phone List</font></label></div>
<br/>
<div >
<textarea name="phone list" placeholder="+447700000000
+330000000000
+610000000000
3900000000000
0100000000000
4477000000000
" name="phone list" placeholder="your phone list" class="listp"  required="" style="height:130px;width:304px;" ></textarea>
</div>
<style>
hr.new24 {border-top: 1px dashed #1919DF; width:73%;}
</style>
<hr class='new24'>
<input type="submit" id="clickp" name="Get info" value="Check The Phone List >>" style="width:300px;">

<div style="padding-top:12px;">
<iframe src="x.php" height="322" width="328" ></iframe>
</div>
</div>
<br/>
<a href="https://t.me/xe0on" target="_blank"><b><font color="#1919DF" face="verdana" size="2px" >X E O N   &#169; 2020</b></a>
</center>
<br/>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script>
	$("#sub").click(function() {
		$.post("ajax.php", {v : $(".ipt").val()}, function(data) {
			$(".list1").val(data);
		})
	})
	$("#clickp").click(function() {
		$.post("ajax.php", {v1 : $(".listp").val()}, function(data) {
			$(".list2").val(data);
		})
	})
</script>
</body>
</html>
</main>
</div>
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/esm/popper.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.1/js/bootstrap.js'></script><script  src="assets/script2.js"></script>

</body>
</html>