<?php

function check ($phone){

	$ch = curl_init();
	
	$url =  "http://apilayer.net/api/validate?access_key=70407c3475e8e1574cbefb9a5384c71e&number=".$phone."&country_code=&format=1";

	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");


	$headers = array();
	$headers[] = "Host: apilayer.net";
	$headers[] = "User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:52.0) Gecko/20100101 Firefox/52.0";
	$headers[] = "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8";
	$headers[] = "Accept-Language: en-US,en;q=0.5";
	$headers[] = "Accept-Encoding: gzip, deflate";
	$headers[] = "Dnt: 1";
	$headers[] = "Connection: close";
	$headers[] = "Upgrade-Insecure-Requests: 1";
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

	$result = curl_exec($ch);
	if (curl_errno($ch)) {
	    echo 'Error:' . curl_error($ch);
	}
	curl_close ($ch);

	return $result;

}

$id = $argv[1];


$all = json_decode(base64_decode($id), true);

$fv = fopen("valid.txt", "a");
$fnv = fopen("notValid.txt", "a");

foreach ($all as $key) {
	$check =  check($key);

	$d = json_decode($check, true);

	if($d['valid']) {
		fputs($fv, $key."\n");
	}else {
		fputs($fnv, $key."\n");
	}
}

fclose($fv);
fclose($fnv);



?>